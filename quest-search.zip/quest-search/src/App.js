import QuestSearch from './components/QuestSearch';
import './App.css';

function App() {
  return (
    <div className="App">
      <QuestSearch />
    </div>
  );
}

export default App;